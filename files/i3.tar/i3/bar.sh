#!/bin/sh


date

while :
do
	sleep 1
done
